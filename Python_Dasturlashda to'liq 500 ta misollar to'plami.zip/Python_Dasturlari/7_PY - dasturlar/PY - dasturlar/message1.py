from tkinter import *



master = Tk()

w = Message(master, text="this is a message")
w.pack()

mainloop()
