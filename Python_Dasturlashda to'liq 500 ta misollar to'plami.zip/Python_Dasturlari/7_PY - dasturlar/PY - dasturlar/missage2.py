from tkinter import *



master = Tk()

w = Message(master, text="this is a relatively long message", width=50)
w.pack()

mainloop()
