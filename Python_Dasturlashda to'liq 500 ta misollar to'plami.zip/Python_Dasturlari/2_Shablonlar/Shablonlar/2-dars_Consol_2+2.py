# -*- coding: utf-8 -*-

from simpletk import *

print("   ") 
print ( "2+2=?" )
print ( "Ответ: 4" )
print ( 'Salom' )

app = TApplication("Первая форма")
app.Run()



