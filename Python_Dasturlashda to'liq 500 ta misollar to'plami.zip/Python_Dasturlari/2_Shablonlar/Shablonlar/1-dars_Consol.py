# -*- coding: utf-8 -*-

from simpletk import *

print("   ") 
print("   SALOM") 
print("       Python") 
print("            Delphi") 
print("                 C++") 
 
app = TApplication("Первая форма")
app.Run()



