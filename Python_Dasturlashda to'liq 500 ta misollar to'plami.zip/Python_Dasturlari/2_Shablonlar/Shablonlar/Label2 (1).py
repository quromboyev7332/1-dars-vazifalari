from tkinter import Label                     
widget = Label(None, text='Hello GUI world!') 
widget.pack()                                 
widget.mainloop()
