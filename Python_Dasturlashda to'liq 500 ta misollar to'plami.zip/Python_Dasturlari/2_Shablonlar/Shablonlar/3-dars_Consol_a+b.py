# -*- coding: utf-8 -*-

from simpletk import *

print("   ") 
a = int ( input() )
b = int ( input() )
c = a + b
print ( c )

app = TApplication("Первая форма")
app.Run()



