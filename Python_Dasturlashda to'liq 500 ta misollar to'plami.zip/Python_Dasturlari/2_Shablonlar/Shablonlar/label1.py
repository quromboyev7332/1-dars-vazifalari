from tkinter import *

master = Tk()

w = Label(master, text="Hello, world!")
w.pack()

mainloop()
