from tkinter.messagebox import askokcancel

askokcancel("Exit", "Really?")
askokcancel("Exit", "Are you sure?")
askokcancel("Exit", "Wanna leave?")
