from tkinter.messagebox import *
showinfo("Spam", "Egg Information")
showwarning("Spam", "Egg Warning")
showerror("Spam", "Egg Alert")
askquestion("Spam", "Question?")
askokcancel("Spam", "Proceed?")
askyesno("Spam", "Got it?")
askyesnocancel("Spam", "Want it?")
askretrycancel("Spam", "Try again?")
