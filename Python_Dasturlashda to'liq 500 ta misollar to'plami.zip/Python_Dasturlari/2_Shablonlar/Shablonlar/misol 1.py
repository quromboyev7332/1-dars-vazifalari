i = 5
print(i)
i = i + 1
print(i) 
s = "Bu ko'p qatorlik satr.\nBu uning ikkinchi qatori."
print(s)
