from tkinter.messagebox import askokcancel, askquestion, showerror

askokcancel("Exit", "Really?")
askokcancel("Exit", "Are you sure?")
askokcancel("Exit", "Wanna leave?")
showerror('Error!', "He's dead, Jim"),
