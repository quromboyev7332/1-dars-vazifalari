from tkinter.messagebox import askquestion

askquestion('Warning', 'You typed "rm *"\nConfirm?'),
