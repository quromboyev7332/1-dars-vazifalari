
# bu izoh belgisi bu belgilar
# terminalga chiqmaydi faqat IZOH
print ( "2+2=?" )  #Bu print funksiyasi
print ( "Javob: 4" )
print ( 'Salom dunyo!') 
  
