from tkinter.messagebox import *

askokcancel("Exit", "Really?")
askokcancel("Exit", "Are you sure?")
askokcancel("Exit", "Wanna leave?")
showerror('Error!', "He's dead, Jim")
askquestion('Warning', 'You typed "rm *"\nConfirm?')
askyesno('Ha ', 'Yo`q ')
showwarning('Diqqat!')
