from graph import *
penColor("magenta")
brushColor("blue")
rectangle(100,100,300,200)
brushColor("yellow")
polygon([(100,100), (200,50), 
      (300,100), (100,100)])
penColor("white")
brushColor("green")
circle(200, 150, 50)
run()
