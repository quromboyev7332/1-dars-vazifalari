

import pip

pip.main(["install", "tkinter", "--user"])
